// MessageRow — one fully-featured row in a message list. Owns its
// own `useReactions` instance so the inline reaction strip AND the
// hover-menu emoji picker share one state — adds land once, the
// realtime echo upserts. Used internally by `<ConversationView>` and
// `<ThreadView>`.
//
// Customers building a custom layout can import this directly to
// reuse the full feature surface (reactions, attachments, hover
// actions, edit/delete, read receipts) without re-wiring.

import type { Message, Uuid } from '@poolse/sdk';
import { useReactions, useUser } from '@poolse/react';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Avatar } from './Avatar.js';
import { EditableMessageBubble } from './EditableMessageBubble.js';
import { MessageActions } from './MessageActions.js';
import { MessageBubble, type BubbleGroupPosition } from './MessageBubble.js';
import { PoolseIcon } from './PoolseIcon.js';

export interface MessageRowProps {
  msg: Message;
  /** Current user's id. Drives self-vs-other styling + edit/delete affordances. */
  meId: string | null;

  // Feature toggles — same set as ConversationView's, but per-row.
  reactions?: boolean;
  attachments?: boolean;
  actions?: boolean;
  /** Pass false in ThreadView since nested threads aren't a thing in v1. */
  threads?: boolean;
  /** WhatsApp-style quote-reply. Defaults true on ConversationView. */
  quotations?: boolean;

  /** Set to `'sent' | 'read'` to render the read-receipt glyph on self messages. */
  readState?: 'sent' | 'read';

  /** Inline-edit state — caller controls. */
  editing?: boolean;
  onStartEdit?: () => void;
  onCancelEdit?: () => void;
  onSaveEdit?: (body: string) => Promise<unknown> | void;
  onDelete?: () => void;
  onOpenThread?: () => void;
  /** Quote-reply pressed. Caller stores the message id and renders the composer chip. */
  onQuote?: () => void;
  /** Caller-supplied display-name lookup for the quoted-card sender. */
  labelFor?: (userId: Uuid) => string;
  /** Click on the quoted card — typically scroll-to-original. */
  onQuotedClick?: (quotedMessageId: Uuid) => void;
  /** Where this bubble sits in a same-sender cluster (WhatsApp-style grouping). */
  groupPosition?: BubbleGroupPosition;
  /** Trim threshold for long messages. 0 disables. */
  maxBodyLength?: number;
  /** Render body as GitHub-flavored Markdown. */
  markdown?: boolean;
  /**
   * Show a colored sender label above the bubble body (other-side
   * only, first / standalone bubbles only). Powered by the SDK's
   * `useUser` hook via the customer's `userResolver`.
   */
  showSenderName?: boolean;
  /**
   * Render an avatar to the LEFT of other-side bubbles. The avatar
   * appears on the LAST / STANDALONE bubble of a cluster;
   * continuation bubbles keep an empty slot the same width so the
   * column stays aligned. Self bubbles get no avatar — your own
   * identity is implicit from the bubble color/side.
   */
  showAvatar?: boolean;
}

export function MessageRow({
  msg,
  meId,
  reactions = true,
  attachments = true,
  actions = true,
  threads = true,
  quotations = true,
  readState,
  editing = false,
  onStartEdit,
  onCancelEdit,
  onSaveEdit,
  onDelete,
  onOpenThread,
  onQuote,
  labelFor,
  onQuotedClick,
  groupPosition = 'standalone',
  maxBodyLength = 0,
  markdown = false,
  showSenderName = false,
  showAvatar = false,
}: MessageRowProps) {
  // Resolve the sender once at the row level so both the avatar slot
  // (rendered here) and the bubble's inline sender label (rendered
  // by `<MessageBubble>` which calls `useUser` itself) hit the same
  // dedup'd cache.
  const { profile: senderProfile } = useUser(msg.sender_id);
  const senderFallbackName = msg.sender_id ? `User ${msg.sender_id.slice(0, 6)}` : 'Unknown';
  const senderName = senderProfile?.displayName ?? senderFallbackName;
  const isSelf = meId !== null && msg.sender_id === meId;

  // Single useReactions instance — both the inline strip and the
  // hover-menu emoji picker use addReaction below. Without sharing,
  // the picker button is decorative.
  const reactionsHook = useReactions(reactions ? msg.id : '', {
    conversationId: msg.conversation_id,
    initialReactions: msg.reactions,
    currentUserId: meId,
  });

  const showReactions = reactions && !msg.deleted_at;
  const showActions = actions && !msg.deleted_at && !editing;
  // Thread pill: only show on the root message of an existing thread
  // (i.e. when reply_count > 0 AND this message isn't itself a reply).
  // ThreadView passes threads={false} so the pill won't show inside the
  // thread side-pane.
  const replyCount = msg.reply_count ?? 0;
  const showThreadPill = threads && !msg.deleted_at && !msg.thread_root_id && replyCount > 0;

  const handleSave = onSaveEdit ?? (async () => undefined);
  const handleCancel = onCancelEdit ?? (() => undefined);

  // Touch reveal: hover doesn't fire on touch devices, so tapping
  // the bubble itself toggles the action toolbar. Desktop continues
  // to reveal on hover/focus via CSS — the tap path no-ops there to
  // avoid hijacking text selection.
  const [actionsOpen, setActionsOpen] = useState(false);
  const rowRef = useRef<HTMLDivElement | null>(null);

  // Auto-close when the user taps anywhere outside this row.
  useEffect(() => {
    if (!actionsOpen) return;
    const onDown = (e: PointerEvent) => {
      const t = e.target;
      if (t instanceof Node && rowRef.current && !rowRef.current.contains(t)) {
        setActionsOpen(false);
      }
    };
    document.addEventListener('pointerdown', onDown);
    return () => document.removeEventListener('pointerdown', onDown);
  }, [actionsOpen]);

  const onRowClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Only fire on touch-only viewports. Desktop keeps hover/focus.
    if (typeof window === 'undefined' || !window.matchMedia('(hover: none)').matches) return;
    // Don't hijack clicks on interactive children — links, attachment
    // images (wrapped in <button>), reaction pills, edit textarea,
    // composer, etc. Use closest() so deep targets are still caught.
    const target = e.target as HTMLElement;
    if (target.closest('a, button, input, textarea, label, select')) return;
    setActionsOpen((o) => !o);
  };

  return (
    <div
      ref={rowRef}
      className={[
        'poolse-message-row',
        isSelf ? 'poolse-message-row--right' : '',
        // Modifier mirrors the bubble's groupPosition so the CSS can
        // tighten the inter-bubble gap inside a cluster (first/middle/
        // last) and widen it between clusters (standalone or the
        // first of a new run).
        `poolse-message-row--${groupPosition}`,
      ]
        .filter(Boolean)
        .join(' ')}
      data-message-id={msg.id}
      data-actions-open={actionsOpen || undefined}
      data-avatar={showAvatar && !isSelf ? true : undefined}
      onClick={onRowClick}
    >
      {editing ? (
        <EditableMessageBubble
          message={msg}
          currentUserId={meId}
          {...(readState ? { readState } : {})}
          editing
          onSave={handleSave}
          onCancel={handleCancel}
        />
      ) : (
        <BubbleWithAvatar
          isSelf={isSelf}
          showAvatar={showAvatar}
          groupPosition={groupPosition}
          senderName={senderName}
          avatarUrl={senderProfile?.avatarUrl ?? null}
        >
          <MessageBubble
            message={msg}
            currentUserId={meId}
            groupPosition={groupPosition}
            maxBodyLength={maxBodyLength}
            markdown={markdown}
            showSenderName={showSenderName}
            showAttachments={attachments}
            {...(readState ? { readState } : {})}
            {...(labelFor ? { labelFor } : {})}
            {...(onQuotedClick ? { onQuotedClick } : {})}
            {...(showActions
              ? {
                  actionsTrigger: (
                    <button
                      type="button"
                      className="poolse-message__chevron"
                      aria-label="Show message actions"
                      aria-expanded={actionsOpen}
                      onClick={(e) => {
                        // Chevron is a child of the row but we don't want the
                        // row's tap-to-toggle to also fire on mobile (chevron
                        // is hidden there anyway, but defensive).
                        e.stopPropagation();
                        setActionsOpen((o) => !o);
                      }}
                    >
                      <PoolseIcon name="chevron-down" size={14} label={null} />
                    </button>
                  ),
                }
              : {})}
          />
        </BubbleWithAvatar>
      )}

      {showReactions && (
        <div className={`poolse-message-row__reactions ${isSelf ? 'is-self' : ''}`}>
          {/* Render reactions from the shared hook's state directly so
              they update in tandem with the hover-menu picker. */}
          <InlineReactions
            reactions={reactionsHook.reactions}
            currentUserId={meId}
            onAdd={(e) => void reactionsHook.addReaction(e)}
            onRemove={(e) => void reactionsHook.removeReaction(e)}
          />
        </div>
      )}

      {showThreadPill && (
        <button
          type="button"
          className={`poolse-thread-pill ${
            isSelf ? 'poolse-thread-pill--right' : 'poolse-thread-pill--left'
          }`}
          onClick={onOpenThread}
          aria-label={`View ${replyCount} ${replyCount === 1 ? 'reply' : 'replies'}`}
        >
          <PoolseIcon name="messages" size={12} label={null} />
          <span>
            {replyCount} {replyCount === 1 ? 'reply' : 'replies'}
          </span>
        </button>
      )}

      {showActions && (
        <div
          className={`poolse-message-row__actions ${
            isSelf ? 'poolse-message-row__actions--right' : 'poolse-message-row__actions--left'
          }`}
        >
          <MessageActions
            {...(reactions
              ? {
                  onReact: (emoji) => {
                    void reactionsHook.addReaction(emoji);
                  },
                }
              : {})}
            {...(threads && onOpenThread ? { onReply: onOpenThread } : {})}
            {...(quotations && onQuote ? { onQuote } : {})}
            {...(msg.body
              ? {
                  onCopy: () => {
                    // Best-effort: navigator.clipboard isn't available in
                    // older browsers / non-HTTPS contexts. Caller can wire
                    // its own toast via the SDK if needed; we just fail
                    // silently here rather than throw inside an onClick.
                    void navigator?.clipboard?.writeText(msg.body ?? '').catch(() => undefined);
                  },
                }
              : {})}
            {...(isSelf && onStartEdit ? { onEdit: onStartEdit } : {})}
            {...(isSelf && onDelete ? { onDelete } : {})}
          />
        </div>
      )}
    </div>
  );
}

// Stripped-down ReactionStrip that uses an external addReaction/
// removeReaction (rather than calling useReactions internally). Lets
// MessageRow share one useReactions across the strip + the hover
// picker. Picker disabled on this internal variant; the hover menu
// handles "add reaction" instead.
function InlineReactions({
  reactions,
  currentUserId,
  onAdd: _onAdd,
  onRemove,
}: {
  reactions: Record<string, string[]>;
  currentUserId: string | null;
  onAdd: (emoji: string) => void;
  onRemove: (emoji: string) => void;
}) {
  const entries = Object.entries(reactions);
  if (entries.length === 0) return null;
  return (
    <div className="poolse-reactions">
      {entries.map(([emoji, users]) => {
        const mine =
          currentUserId !== null && currentUserId !== undefined && users.includes(currentUserId);
        return (
          <button
            key={emoji}
            type="button"
            className={`poolse-reaction-pill${mine ? ' poolse-reaction-pill--mine' : ''}`}
            onClick={() => {
              if (mine) onRemove(emoji);
              else _onAdd(emoji);
            }}
            aria-pressed={mine}
            aria-label={`${emoji} reacted by ${users.length} ${users.length === 1 ? 'user' : 'users'}`}
          >
            <span>{emoji}</span>
            <span className="poolse-reaction-pill__count">{users.length}</span>
          </button>
        );
      })}
    </div>
  );
}

// Wraps the bubble in a flex row with an avatar slot to the left
// (other-side bubbles only). Self bubbles and group-chat-off
// configurations pass through unchanged.
//
// The slot is ALWAYS the same width (28px + 6px gap) when `showAvatar`
// is on — even on continuation bubbles where the avatar itself is
// hidden — so the column stays aligned across a multi-bubble cluster.
function BubbleWithAvatar({
  isSelf,
  showAvatar,
  groupPosition,
  senderName,
  avatarUrl,
  children,
}: {
  isSelf: boolean;
  showAvatar: boolean;
  groupPosition: BubbleGroupPosition;
  senderName: string;
  avatarUrl: string | null;
  children: ReactNode;
}) {
  if (isSelf || !showAvatar) return <>{children}</>;

  const isLastOfCluster = groupPosition === 'last' || groupPosition === 'standalone';

  return (
    <div className="poolse-bubble-shell">
      <div className="poolse-bubble-shell__avatar">
        {isLastOfCluster ? <Avatar src={avatarUrl} name={senderName} size="sm" /> : null}
      </div>
      {children}
    </div>
  );
}
