# Changelog

All notable changes to `@poolse/react` are documented here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versions follow
[semver](https://semver.org).

## [2.0.0] — 2026-06-03

Lockstep release with `@poolse/sdk@2.0.0` and `@poolse/react-ui@2.0.0`.

### Breaking

- **`useUser(externalId)`** — was `useUser(userId)`. The hook now
  consumes the tenant's own user id. Pass the value from
  `message.sender_external_id`, `membership.external_id`, or any
  other external_id-shaped field on the wire.
- **`useTyping(conversationId).typing`** now returns `Set<externalId>`
  (was `Set<userId>`). Same for `usePresence(conversationId).online`.
- **`useMembers(conversationId).removeMember(externalId)`** — was
  `removeMember(userId)`. The hook translates external_id → user_id
  internally; the DELETE endpoint still takes user_id but you don't
  see it.

### Migration

See `MIGRATING.md` at the repo root.

## [1.1.0] — 2026-06-02

Lockstep release with `@poolse/sdk@1.1.0` and `@poolse/react-ui@1.1.0`.
No API changes in `@poolse/react` itself — version bumped to keep the
three packages in sync, so customers can pin one version across the
whole client surface.

### Changed

- README rewritten with a full per-hook reference: signatures, return
  shapes, the realtime channels each hook subscribes to, the optimistic
  send + thread routing strategy in `useMessages`, the buffered-reads
  race fix in `useMembers`, the cache + dedup semantics in `useUser`,
  and the synchronous-snapshot rollback pattern used by edits and
  optimistic removes.
- Repo-wide prettier formatting fixes (whitespace only).

## [1.0.0-beta.0] — 2026-06-01

First beta of the stable API. Promotes the full 0.2.x hook surface
(useMessages with reply_count routing, useThread with full-thread
fetch, useMembers with buffered read-receipt events,
useConversations with unreadCounts + markConversationRead) to a
stable namespace. No breaking changes relative to `0.2.0-alpha.7`
— version bump + removed verbose diagnostic logs.

## [0.2.0] — 2026-06-01

### Fixed

- Realtime read receipts now actually fire. The server-side broadcast
  call in `Messaging.do_mark_read` was missing — the alpha.2 commit
  added the channel handler and the SDK subscription but the broadcast
  itself never made it into the commit, so no `member:read` event was
  ever sent. Fixed in the matching server release; `useMembers` also
  logs received events as `[poolse] member:read received` for easy
  observability.

### Changed — thread replies routed to reply_count only

- `useMessages` no longer adds incoming thread replies to the main
  feed — replies belong to the side-pane that `useThread` populates.
  Realtime `message:new` with `thread_root_id` set now bumps the
  root's `reply_count` and skips the upsert. Matches the new server
  behavior (`WHERE thread_root_id IS NULL` on `list_messages`), so
  refresh and realtime stay consistent.
- `useThread` default page size raised from 50 → 500 so a typical
  thread loads in one round-trip. `loadMore` remains as an escape
  hatch.
- `useMembers` now buffers `member:read` events that fire before the
  initial fetch lands, then replays them once members are loaded.
  Fixes the realtime read-receipt race where reads arriving in the
  subscribe → fetch-response window were silently dropped.

### Added

- `useMessages` now maintains `Message.reply_count` live — increments
  on inbound thread reply, decrements on reply soft-delete. No server
  round-trip; the thread pill in `<MessageRow>` updates immediately.

### Fixed

- `useMembers` catch path now `console.error`s the underlying error
  with a `[poolse]` prefix so silent failures are debuggable from
  DevTools.

### Added (continued)

- `useMessages.edit(messageId, body)` — optimistic edit with rollback
  on server error. Server enforces sender-only authorization.
- `useMessages.delete(messageId)` — optimistic soft-delete (sets
  `deleted_at` + null body locally, rolls back on error).
- `useMessages.markReadUpTo(messageId)` — wraps
  `chat.conversations.one(id).messages.markRead`; advances the
  caller's read cursor and triggers server-side read-receipt
  broadcasts to other members.
- `useConversations` now exposes `unreadCounts: Record<convId, number>`
  plus `markConversationRead(convId)` for sidebar-badge UIs.
- `useThread.edit(messageId, body)` / `useThread.delete(messageId)`
  for inline reply editing inside `<ThreadView>`.

### Changed

- `useMembers(conversationId)` now treats an empty string id as
  "skip fetch" (returns `{ members: [], loading: false }`) so
  callers can conditionally enable member loading without wrapping
  in a `enabled ?` guard.
- `useMembers` subscribes to the new `member:read` realtime event
  and advances the matching membership's `last_read_message_id` /
  `last_read_at` in place. The sender's check-double glyph now
  flips in real time without a refetch.
- Provider auto-resolves the SDK's new default `apiUrl` when none
  is passed in config.

## [0.1.1] — 2026-06-01

### Fixed

- `useMessages.send()` now stamps the optimistic temp message's
  `sender_id` with the current user's id (via `useMe` internally).
  Without this, self-sent messages briefly rendered on the "other"
  side of the chat until the realtime echo replaced them.

## [0.1.0] — 2026-06-01

First publishable release.

### Added

- `<PoolseProvider>` — mount-once SDK instance with ref-stable callbacks
  (safe to pass `config={{getToken: () => ...}}` inline on every render).
- `usePoolse()` — raw `Poolse` instance escape hatch.
- Realtime hooks: `useMe`, `useConversations`, `useConversation`,
  `useMembers`, `useMessages`, `useThread`, `useReactions`, `useTyping`,
  `usePresence`, `useRealtimeStatus`.
- Attachments: `useAttachmentUpload`, `useAttachmentUrl`.
- Real-time conversation list — `useConversations` subscribes to the
  user's `user:<id>` channel and prepends on `conversation:created`
  push (no manual refetch needed).
- Optimistic message send with id-based dedup: `useMessages.send()`
  inserts under the same id the server will assign, so realtime echo
  upserts in place.
